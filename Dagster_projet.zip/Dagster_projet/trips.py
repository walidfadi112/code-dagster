import pandas as pd  # type: ignore
import requests  # type: ignore
import duckdb  # type: ignore
import os
from dagster import asset  # type: ignore
from . import constants  

@asset
def taxi_trips_file() -> None:
    """ 
    Récupère les fichiers Parquet bruts des trajets en taxi.
    """
    month_to_fetch = '2023-03'
    raw_trips = requests.get(
        f"https://d37ci6vzurychx.cloudfront.net/trip-data/yellow_tripdata_{month_to_fetch}.parquet"
    )

    with open(constants.TAXI_TRIPS_TEMPLATE_FILE_PATH.format(month_to_fetch), "wb") as output_file:
        output_file.write(raw_trips.content)

@asset
def taxi_zones_file() -> None:
    """ 
    Récupère les fichiers CSV contenant les identifiants et noms des zones de taxi. 
    """
    raw_zones = requests.get(
        "https://community-engineering-artifacts.s3.us-west-2.amazonaws.com/dagster-university/data/taxi_zones.csv"
    )

    with open(constants.TAXI_ZONES_FILE_PATH, "wb") as output_file:
        output_file.write(raw_zones.content)

@asset(deps=["taxi_trips_file"])
def taxi_trips() -> None:
    """Charge les trajets en taxi dans DuckDB."""

    query = """
    CREATE OR REPLACE TABLE trips AS (
        SELECT
            VendorID AS vendor_id, 
            PULocationID AS pickup_zone_id, 
            DOLocationID AS dropoff_zone_id, 
            RatecodeID AS rate_code_id, 
            payment_type AS payment_type, 
            tpep_dropoff_datetime AS dropoff_datetime, 
            tpep_pickup_datetime AS pickup_datetime, 
            trip_distance AS trip_distance, 
            passenger_count AS passenger_count, 
            total_amount AS total_amount 
        FROM 'data/raw/taxi_trips_2023-03.parquet'
    );
    """

    conn = duckdb.connect("data/dagster_duckdb.db")
    conn.execute(query)
    conn.close()

    print(" Données chargées dans DuckDB (table trips).")

@asset(deps=["taxi_zones_file"])
def taxi_zones() -> None:
    """Charge les zones de taxi dans DuckDB."""

    query = """
    CREATE OR REPLACE TABLE zones AS
    SELECT 
        LocationID AS zone_id,
        zone,
        borough,
        the_geom AS geometry
    FROM read_csv_auto('data/raw/taxi_zones.csv');
    """

    conn = duckdb.connect("data/dagster_duckdb.db")
    conn.execute(query)
    conn.close()

    print(" Données chargées dans DuckDB (table zones).")
