import dagster as dg  # type: ignore
from dagster import asset  # type: ignore
import matplotlib.pyplot as plt  # type: ignore
import geopandas as gpd  # type: ignore
import duckdb  # type: ignore
import os
import pandas as pd  # type: ignore
from . import constants  

@asset(deps=["taxi_trips", "taxi_zones"])
def calculate_taxi_metrics() -> pd.DataFrame:
    """Calcule des statistiques sur les trajets en taxi."""
    query = """
    SELECT
        t.pickup_datetime,
        t.passenger_count,
        z.zone AS pickup_zone
    FROM trips t
    JOIN taxi_zones z ON t.pickup_zone_id = z.zone_id
    """

    conn = duckdb.connect("data/dagster_duckdb.db")
    df = conn.execute(query).fetchdf()
    conn.close()

    metrics = df.groupby("pickup_zone").agg(
        total_trips=("pickup_datetime", "count"),
        avg_passenger_count=("passenger_count", "mean")
    ).reset_index()

    print(" Calcul des métriques terminé.")
    return metrics

@asset(deps=["calculate_taxi_metrics"])
def generate_taxi_report(calculate_taxi_metrics: pd.DataFrame) -> None:
    """Génère un rapport CSV avec les métriques des trajets en taxi."""
    output_path = "data/outputs/taxi_report.csv"
    calculate_taxi_metrics.to_csv(output_path, index=False)

    print(f" Rapport généré : {output_path}")

@asset(deps=["taxi_trips", "taxi_zones"])
def manhattan_stats() -> None:
    """ 
    Calcule les statistiques des trajets en taxi pour Manhattan et les stocke au format GeoJSON.
    """
    query = """
        SELECT 
            zones.zone, 
            zones.borough, 
            zones.geometry, 
            COUNT(1) AS num_trips 
        FROM trips 
        LEFT JOIN zones ON trips.pickup_zone_id = zones.zone_id 
        WHERE borough = 'Manhattan' AND geometry IS NOT NULL 
        GROUP BY zone, borough, geometry 
    """

    conn = duckdb.connect("data/dagster_duckdb.db")
    trips_by_zone = conn.execute(query).fetchdf()
    conn.close()

    trips_by_zone["geometry"] = gpd.GeoSeries.from_wkt(trips_by_zone["geometry"])
    trips_by_zone = gpd.GeoDataFrame(trips_by_zone)

    with open(constants.MANHATTAN_STATS_FILE_PATH, 'w') as output_file:
        output_file.write(trips_by_zone.to_json())

    print(f" Fichier GeoJSON enregistré : {constants.MANHATTAN_STATS_FILE_PATH}")

@asset(deps=["manhattan_stats"])
def manhattan_map() -> None:
    """ 
    Génère une carte des trajets en taxi à Manhattan et l'enregistre sous forme d'image. 
    """
    trips_by_zone = gpd.read_file(constants.MANHATTAN_STATS_FILE_PATH)

    fig, ax = plt.subplots(figsize=(10, 10))
    trips_by_zone.plot(column="num_trips", cmap="plasma", legend=True, ax=ax, edgecolor="black")

    ax.set_title("Nombre de trajets par zone de taxi à Manhattan")
    ax.set_xlim([-74.05, -73.90])
    ax.set_ylim([40.70, 40.82])

    plt.savefig(constants.MANHATTAN_MAP_FILE_PATH, format="png", bbox_inches="tight")
    plt.close(fig)

    print(f" Carte enregistrée : {constants.MANHATTAN_MAP_FILE_PATH}")

@asset(deps=["taxi_trips"])
def trips_by_week() -> None:
    """ 
    Agrège les trajets par semaine et génère un fichier CSV contenant les statistiques hebdomadaires.
    """
    query = """
    SELECT 
        strftime('%Y-%m-%d', pickup_datetime) AS period,  
        COUNT(*) AS num_trips,
        SUM(passenger_count) AS passenger_count,
        SUM(total_amount) AS total_amount,
        SUM(trip_distance) AS trip_distance
    FROM trips
    GROUP BY period
    ORDER BY period;
    """

    conn = duckdb.connect("data/dagster_duckdb.db")
    df = conn.execute(query).fetchdf()
    conn.close()

    df.to_csv(constants.TRIPS_BY_WEEK_FILE_PATH, index=False)

    print(f" Fichier CSV des trajets par semaine enregistré : {constants.TRIPS_BY_WEEK_FILE_PATH}")
